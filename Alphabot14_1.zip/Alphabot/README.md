# ```SELF-BOT```
<p align="center">
<a href="https://github.com/zeeoneofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/zeeoneofc?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/Alphab0t12/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/zeeoneofc/Alphab0t12?color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/Alphab0t12/network/members"><img title="Forks" src="https://img.shields.io/github/forks/zeeoneofc/Alphab0t12?color=red&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/Alphab0t12/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zeeoneofc/Alphab0t12?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/zeeoneofc/Alphab0t12"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/zeeoneofc/Alphab0t12/"><img title="Size" src="https://img.shields.io/github/repo-size/zeeoneofc/Alphab0t12?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fzeeoneofc%2FAlphab0t12&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/zeeoneofc/Alphab0t12/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
    </p>

-------

## `ADD BUILDPACK`

```
> heroku/nodejs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
> https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## `CHANGE SESSION`

[`Click Here`](https://github.com/zeeoneofc/Alphab0t12/blob/master/session.json#L1)

## `SETTING`

- Owner number [Here](https://github.com/zeeoneofc/Alphab0t12/blob/master/settings.json#L1)
- Owner name [Here](https://github.com/zeeoneofc/Alphab0t12/blob/master/settings.json#L1)
- Botname [Here](https://github.com/zeeoneofc/Alphab0t12/blob/master/settings.json#L1)

## `CHANGE DYNO`

Off in web nya

----------

<p align="center">
  <a href="https://youtu.be/_CP2_1Yqauo"><img src="https://a.top4top.io/p_20888ybra1.jpg" />
</p>

## ```HOW TO DEPLOY```

[`Click Here For Tutorial`](https://youtu.be/5HgB__wARjM)<br>

----------

<p align="center">
  <a href="https://youtu.be/_CP2_1Yqauo"><img src="https://a.top4top.io/p_2081imvxm1.jpg" />
</p>


## ```COFFEE```

- [`SAWERIA`](https://saweria.co/zeeoneofc)

## ```GROUP SUPPORT```

- [`Alphabot 1`](https://chat.whatsapp.com/EU890BcXjyBDkNaUT5WmYV)
- [`Alphabot 2`](https://chat.whatsapp.com/E8NExJwIbhBJYzssfqJNsE)
- [`Alphabot 3`](https://chat.whatsapp.com/KCSqHTky1apG7ApePsfiPy)

## `THANKS TO`

- Allah SWT.
- My parents
- All Friends
- All Contributors
- All Creator Bot
